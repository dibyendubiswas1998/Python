from django.shortcuts import render, HttpResponseRedirect
from .forms import Validation
from .models import User

# For Adding Data:-----------------
def Index(request):
    if request.method == 'POST':
        fm = Validation(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            pa = fm.cleaned_data['password']
            print(nm, em, pa)
            reg = User(name=nm, email=em, password=pa)
            reg.save()
            # fm.save()
            fm = Validation()
    else:
        fm = Validation()
    stud = User.objects.all()
    return render(request, 'index.html', {'form':fm, 'stu':stud})

# For Delete Data:------------------
def delete_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')
        

# For Edit or Update Data:-----------
def update_data(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        fm = Validation(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = User.objects.get(pk=id)
        fm = Validation(instance=pi)
    return render(request, 'update.html', {'form':fm, 'id':id})