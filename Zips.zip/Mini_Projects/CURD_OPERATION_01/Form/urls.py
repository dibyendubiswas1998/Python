from django.urls import path
from .import views

urlpatterns = [
    path('', views.Index, name='Index'),
    path('delete/<int:id>/', views.delete_data, name='Delete'),
    path('/<int:id>/', views.update_data, name='Update'),

]

