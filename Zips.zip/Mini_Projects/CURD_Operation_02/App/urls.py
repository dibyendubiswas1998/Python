from django.urls import path
from .import views

urlpatterns = [
    path('', views.AddData, name='AddData'),
    path('database/', views.Database, name='Database'),
    path('delete/<int:id>/', views.DeleteData, name='DeleteData'),
    path('editdata/<int:id>/', views.EditData, name='EditData'),
    
]
