from django import forms
from .models import Employee

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields =  ['fulname', 'mobile', 'empcode', 'position']
        widgets = {
            'fulname':forms.TextInput(attrs={'placeholder':'Enter Your Full Name', 'class':'myclass1'}),
            'mobile':forms.TextInput(attrs={'placeholder':'Enter Your Mobile Number', 'class':'myclass1'}),
            'empcode':forms.TextInput(attrs={'placeholder':'Enter Your Employee Code', 'class':'myclass2'}),
        }
        labels = {
            'fulname':'Full Name',
            'mobile':'Mobile Number',
            'empcode':'Employee Code',
            'position':'Position'
        }
    def __init__(self, *args, **kwargs):
            super(EmployeeForm, self).__init__(*args, **kwargs)
            self.fields['position'].empty_label = "Select"
            