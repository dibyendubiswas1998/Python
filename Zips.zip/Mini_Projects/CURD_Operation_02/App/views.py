from django.shortcuts import render, HttpResponseRedirect
from .forms import EmployeeForm
from .models import Employee

# For Add Data:---
def AddData(request):
    if request.method == 'POST':
        fm = EmployeeForm(request.POST)
        if fm.is_valid():
            fm.save()
            fm = EmployeeForm()
    else:
         fm = EmployeeForm()
    return render(request, 'index.html', {'form':fm})

# For Database:----
def Database(request):
    edata = Employee.objects.all()
    return render(request, 'database.html', {'emd':edata, 'title':'employee database'})

# For Delete Data:---------
def DeleteData(request, id):
    if request.method == 'POST':
        pi = Employee.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/database/')

# For Update Data:---------
def EditData(request, id):
    if request.method == 'POST':
        pi = Employee.objects.get(pk=id)
        fm = EmployeeForm(request.POST, instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi = Employee.objects.get(pk=id)
        fm = EmployeeForm(instance=pi)
    return render(request, 'editdata.html', {'form':fm})
