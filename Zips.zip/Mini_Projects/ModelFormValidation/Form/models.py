from django.db import models

class Form1(models.Model):
    fname = models.CharField(max_length=60)
    lname = models.CharField(max_length=40)
    email = models.EmailField(max_length=120)
    phone = models.CharField(max_length=10)
    location = models.CharField(max_length=40)
    password = models.CharField(max_length=10)
