from django.shortcuts import render
from .forms import FormValidation
from .models import Form1

def Index(request):
    if request.method == 'POST':
        fm = FormValidation(request.POST)
        if fm.is_valid():
            fn = fm.cleaned_data['fname']
            lm = fm.cleaned_data['lname']
            em = fm.cleaned_data['email']
            ph = fm.cleaned_data['phone']
            lo = fm.cleaned_data['location']
            pas = fm.cleaned_data['password']
            reg = Form1(fname=fn, lname=lm, email=em, phone=ph, location=lo, password=pas)
            reg.save()
            fm = FormValidation()
    else:
        fm = FormValidation()
    return render(request, 'index.html', {'form':fm})
    