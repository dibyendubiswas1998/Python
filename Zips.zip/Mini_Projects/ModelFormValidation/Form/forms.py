from django import forms
from .models import Form1

class FormValidation(forms.ModelForm):
    class Meta:
        model = Form1
        fields = '__all__'
        widgets = {
            'fname':forms.TextInput(attrs={'placeholder':'Your Frist Name', 'class':'myclass'}),
            'lname':forms.TextInput(attrs={'placeholder':'Your Last Name', 'class':'myclass'}),
            'email':forms.TextInput(attrs={'placeholder':'Your Email Id', 'class':'myclass'}),
            'phone':forms.TextInput(attrs={'placeholder':'Your Phone Number', 'class':'myclass'}),
            'location':forms.TextInput(attrs={'placeholder':'Your Location', 'class':'myclass'}),
            'password':forms.PasswordInput(attrs={'placeholder':'Your Password', 'class':'myclass', 'min_length':5}),
            
        }
        labels = {
            'fname':'Frist Name',
            'lname':'Last Name',
            'email': 'Email Id',
            'phone': 'Phone Number',
            'password':'Password'
        }
        

        